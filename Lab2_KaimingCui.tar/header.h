/**
 *Kaiming Cui
 *CSCI 503
 *Lab2
 *The tar ball contains a Makefile, a source code of lab2 called "MyShell.c", and a README.txt and this header.h
 *
 */
